﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DictionaryClassType
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Dictionary<int, Element> dict = new Dictionary<int, Element>();
            Element el1 = new Element()
            {
                Name = "Potassium",
                symbol = "K"
            };
            Element el2 = new Element() { Name = "Sodium", symbol = "Na" };
            dict.Add(1,el1);//int,Element
            dict.Add(2,el2);

          

            Console.WriteLine(dict.Count);

            //access all key/value pairs
            foreach(KeyValuePair<int, Element> kvp in dict)
            {
                Element el = kvp.Value;
                Console.WriteLine($"Key : {kvp.Key}, Symbol : {el.symbol}, Name : {el.Name}");
            }





        }
    }
    class Element
    {
        public string Name { get; set; }
        public string symbol { get; set; }
    }
}
